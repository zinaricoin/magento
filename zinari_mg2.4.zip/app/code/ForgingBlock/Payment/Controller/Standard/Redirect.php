<?php

namespace ForgingBlock\Payment\Controller\Standard;

use Magento\Framework\Controller\ResultFactory;

class Redirect extends \Magento\Framework\App\Action\Action
{
    
    protected $_checkoutSession;    
    protected $_orderFactory;    
    protected $_order;    
    protected $_logger;
    
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Psr\Log\LoggerInterface $logger
    ) {
        $this->_checkoutSession = $checkoutSession;
        $this->_orderFactory = $orderFactory;
        $this->_logger = $logger;
        parent::__construct($context);
    }

    protected function _getOrder($incrementId= null)
    {
        if (!$this->_order) {
            $incrementId = $incrementId ? $incrementId : $this->_getCheckout()->getLastRealOrderId();
            $this->_order = $this->_orderFactory->create()->loadByIncrementId($incrementId);
        }
        return $this->_order;
    }

    
    protected function _getCheckout()
    {
        return $this->_checkoutSession;
    }

    public function execute()
    {   
        try {
            if (!$this->_getOrder()->getId()) {
                throw new \Magento\Framework\Exception\LocalizedException(__('No order for processing found'));
            }
            $this->_getCheckout()->setForgingBlockQuoteId($this->_getCheckout()->getQuoteId());
            $this->_view->loadLayout()->renderLayout();
            $this->_getCheckout()->unsQuoteId();
            $this->_getCheckout()->unsRedirectUrl();
            return;
        } catch (\Exception $e) {
            $this->_logger->critical($e);
        }
        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        return $resultRedirect->setPath('checkout/cart');
    }
}
