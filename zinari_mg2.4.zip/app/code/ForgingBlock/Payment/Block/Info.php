<?php


namespace ForgingBlock\Payment\Block;

class Info extends \Magento\Payment\Block\Info
{

    protected $_template = 'ForgingBlock_Payment::info.phtml';
    
    protected function _convertAdditionalData()
    {        
        return $this;
    }

    
    public function toPdf()
    {        
        return $this->toHtml();
    }
}