<?php
namespace ForgingBlock\Payment\Model;

require_once(__DIR__.'/lib/Forgingblock.php');


class Payment extends \Magento\Payment\Model\Method\AbstractMethod
{
    const CODE = 'forgingblock';        

    protected $_code = self::CODE;

    protected $_isGateway  = true;
    protected $_canAuthorize = false;
    protected $_canCapture = false;
    protected $_canUseInternal = false;
    protected $_canUseCheckout = true;
    protected $_isInitializeNeeded      = true;
    protected $_canUseForMultishipping = false;
    protected $_canVoid = false;
    protected $_canRefund = false;
    protected $_canRefundInvoicePartial     = false;

    protected $_formBlockType = 'ForgingBlock\Payment\Block\Form';
    protected $_infoBlockType = 'ForgingBlock\Payment\Block\Info';

    protected $_order;    
    protected $_debugger;    
    protected $_urlBuilder;    
    protected $_checkoutSession;
    protected $_localeResolver;
    protected $_forgingblockHelper;


    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory,
        \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory,
        \Magento\Payment\Helper\Data $paymentData,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Payment\Model\Method\Logger $logger,
        \Magento\Framework\UrlInterface $urlBuilder,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Psr\Log\LoggerInterface $debugger,
        \Magento\Framework\Locale\ResolverInterface $localeResolver,
        \ForgingBlock\Payment\Helper\Data $forgingblockHelper,
		\Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,		
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        parent::__construct(
            $context,
            $registry,
            $extensionFactory,
            $customAttributeFactory,
            $paymentData,
            $scopeConfig,
            $logger,
            $resource,
            $resourceCollection,
            $data
        );
        $this->_urlBuilder = $urlBuilder;
        $this->_checkoutSession = $checkoutSession;
        $this->_debugger = $debugger;
        $this->_localeResolver = $localeResolver;
        $this->_forgingblockHelper = $forgingblockHelper;
        //$this->transactionRepository = $transactionRepository;
        //$this->transactionBuilder = $transactionBuilder;
    }

    public function isAvailable(\Magento\Quote\Api\Data\CartInterface $quote = null)
    {
        return parent::isAvailable($quote);
    }

    public function getOrder()
    {
        if (!$this->_order) {
            $this->_order = $this->_checkoutSession->getLastRealOrder();
        }
        return $this->_order;
    }

    public function getCheckoutRedirectUrl()
    {
        return false;
    }

    public function getOrderPlaceRedirectUrl()
    {
        return $this->_urlBuilder->getUrl('forgingblock/standard/redirect');
    }

    
    public function validate()
    {
        parent::validate();
        $this->_debugger->debug('validate');
        return;
    }
   


    public function initialize($paymentAction, $stateObject)
    {
        $this->_debugger->debug('initialize');
        $stateObject->setState(\Magento\Sales\Model\Order::STATE_PENDING_PAYMENT);
        $stateObject->setStatus('pending_payment');
        $stateObject->setIsNotified(false);
        return $this;
    }


	
    public function getUrl()
    {        
		
		
		$order =  $this->getOrder();		
		$newstatus = $this->getConfigData('norder_status');		
		$order->setStatus($newstatus);
		$order->save();		
		
		$returnURL = $this->_urlBuilder->getUrl("checkout/onepage/success", array('_secure' => true));  	  
		$notifyURL = $this->_urlBuilder->getUrl("forgingblock/standard/notify", array('_secure' => true)); 
		$notifyURL .= '?orderid='.$order->getRealOrderId();
			  
		$trmode = ($this->getConfigData('pgmode') == '0') ? 'live' : 'test';  		
		
		$forgingblockAPI = new \ForgingblockAPI($trmode);	 
		
		
	    
    	$forgingblockAPI->SetValue('trade', $this->getConfigData('pgtrade_id'));	 
  
		$forgingblockAPI->SetValue('token', $this->getConfigData('pgtoken'));
		$forgingblockAPI->SetValue('amount', round($order->getGrandTotal(), 2));								
	  
		$forgingblockAPI->SetValue('currency', $order->getBaseCurrencyCode());		
		$forgingblockAPI->SetValue('link', $returnURL);
		$forgingblockAPI->SetValue('notification', $notifyURL);
		$forgingblockAPI->SetValue('order', $order->getRealOrderId());
		
		$resar = $forgingblockAPI->CreateInvoice();
	  	
		$Error = $forgingblockAPI->GetError();
		if ($Error) {
	 		return  $Error;
			
		}
		else {
			$payurl	= $forgingblockAPI->GetInvoiceURL();	
			return $payurl;		
		}		

    }

    protected function _mergePaymentSystems($data)
    {
        $systems = explode(",", $this->getConfigData('payment_system'));
        if (in_array('Controlled', $systems)) {
            return $data;
        } 
        foreach ((array) $systems as $system) {
            $data[$system] = '1';
        }
        return $data;
    }




}